def printPretty(data):
    for i in data:
        print(i, end=" ")
    print()


def readFile(filename):
    file = open(filename, 'r')
    data = ["dateDone", "type", rep, weight]
    contents = file.readlines()
    for line in contents:
        dateDone, type, rep, weight = line.split(',')
        data.append([int(dateDone), type, int(rep), int(weight)])
    file.close()
    return data


files = input("Enter a filename: ")

printPretty(readFile(files))

