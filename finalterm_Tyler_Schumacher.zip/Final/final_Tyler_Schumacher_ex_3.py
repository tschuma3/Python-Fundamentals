def listToDict(listOfData):
    it = iter(listofData)
    dictWords = dict.fromkeys(listofData, 4)
    dictWords = {i: listofData[i] for i in range(0, len(listofData))}
    return dictWords


listofData = [["Oct 11 2017", "Back Squat", 10, 45],
              ["Oct 11 2017", "Back Squat", 10, 135],
              ["Oct 11 2017", "Barbell Bench Press", 4, 45],
              ["Oct 11 2017", "Barbell Bench Press", 4, 125],
              ["Sep 28 2017", "Back Squat", 1, 4, 260],
              ["Sep 28 2017", "Back Squat", 1, 4, 260],
              ["Sep 28 2017", "Barbell Bench Press", 1, 10, 45],
              ["Sep 28 2017", "Barbell Bench Press", 1, 8, 135]]

print(listofData)

print(listToDict(listofData))
