''''
In the last problem I would start off by getting the data from the previous functions.
I would call the function. After this I would use plt to print make the plotss and print
the data out for the respected graphs. I would also import matplotlib.pyplot as plt to be
able to print out the graphs.
'''