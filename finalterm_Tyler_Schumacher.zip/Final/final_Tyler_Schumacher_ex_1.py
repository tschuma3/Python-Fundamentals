# Calculates the one rep max
def OneRepMax(rep, weight):
    oneRepMax = int(weight) * 36 / 37 - int(rep)

    print("\nYour one rep max is: " + str(oneRepMax))


# Asks for the users reps and weight
rep = input("Please input a rep: ")
weight = input("\nPlease input a weight: ")

# Prints out the one rep max
OneRepMax(rep, weight)
