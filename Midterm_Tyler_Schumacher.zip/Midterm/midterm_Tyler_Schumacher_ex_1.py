
# Calculates which numbers are divisible by 3
def allDivisibleBy3(num):
    i = 1
    while i < num:
        j = i
        i = i + 1
        if j % 3 == 0:
            yield j
# Prints out the numbers that are divisible by 3 only
for i in allDivisibleBy3(100):
    print(i)