# This function repeats everyday at a specific time
def repeatEveryDay():
    '''
    This would collect the time based off of datetime.
    If the time is at that time then the function will run.
    Otherwise it waits.
    '''

# The decorator allows for the sayHello function to be repeated everyday
# based of of the
@repeatEveryDay
def sayHello():
    print('Hello!')